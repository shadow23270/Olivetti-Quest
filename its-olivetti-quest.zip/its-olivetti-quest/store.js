const fs = require("fs");
const path = require("path");

const DATA_DIR = path.join(__dirname, "data");
const DATA_FILE = path.join(DATA_DIR, "scores.json");

let scores = [];

function ensureDataFile() {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  if (!fs.existsSync(DATA_FILE)) {
    fs.writeFileSync(DATA_FILE, "[]", "utf8");
  }
}

function load() {
  ensureDataFile();
  try {
    const raw = fs.readFileSync(DATA_FILE, "utf8");
    scores = JSON.parse(raw);
    if (!Array.isArray(scores)) scores = [];
  } catch (err) {
    console.error("Impossibile leggere data/scores.json, riparto da lista vuota:", err.message);
    scores = [];
  }
}

function persist() {
  fs.writeFileSync(DATA_FILE, JSON.stringify(scores, null, 2), "utf8");
}

function todayKey() {
  return new Intl.DateTimeFormat("sv-SE", { timeZone: "Europe/Rome" }).format(new Date());
}

function addScore({ name, score, levelsCompleted, durationMs }) {
  const entry = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    name,
    score,
    levelsCompleted,
    durationMs,
    createdAt: new Date().toISOString(),
    dayKey: todayKey(),
  };
  scores.push(entry);
  persist();
  return entry;
}

function getTodayLeaderboard(limit = 100) {
  const key = todayKey();
  return scores
    .filter((e) => e.dayKey === key)
    .slice()
    .sort((a, b) => b.score - a.score || a.durationMs - b.durationMs)
    .slice(0, limit)
    .map((e, i) => ({
      rank: i + 1,
      name: e.name,
      score: e.score,
      levelsCompleted: e.levelsCompleted,
      durationMs: e.durationMs,
      createdAt: e.createdAt,
    }));
}

load();

module.exports = { addScore, getTodayLeaderboard, todayKey };
