/* Carica e mostra la classifica dei punteggi registrati oggi.
 * Se il server non risponde, mostra la classifica salvata su questo dispositivo. */

(function () {
  const container = document.getElementById("leaderboard-content");
  const MEDALS = ["🥇", "🥈", "🥉"];

  function escapeHtml(str) {
    const div = document.createElement("div");
    div.textContent = str;
    return div.innerHTML;
  }

  function formatDuration(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const mm = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
    const ss = String(totalSeconds % 60).padStart(2, "0");
    return `${mm}:${ss}`;
  }

  function getLastResult() {
    try {
      const raw = sessionStorage.getItem("its-quest-last-result");
      return raw ? JSON.parse(raw) : null;
    } catch (err) {
      return null;
    }
  }

  function render(entries, notice) {
    const noticeHtml = notice ? `<p class="offline-notice">${notice}</p>` : "";

    if (entries.length === 0) {
      container.innerHTML = `${noticeHtml}<p class="empty-state">Nessuna squadra ha ancora giocato oggi.<br/>Siate i primi! 🕹️</p>`;
      return;
    }

    const lastResult = getLastResult();
    let highlightedOnce = false;

    const rows = entries
      .map((e) => {
        const medal = e.rank <= 3 ? MEDALS[e.rank - 1] : e.rank;
        const isYou =
          !highlightedOnce && lastResult && e.name === lastResult.name && e.score === lastResult.score;
        if (isYou) highlightedOnce = true;

        return `
          <tr class="rank-${e.rank <= 3 ? e.rank : ""} ${isYou ? "you" : ""}">
            <td>${medal}</td>
            <td>${escapeHtml(e.name)}</td>
            <td>${e.score}</td>
            <td>${formatDuration(e.durationMs)}</td>
          </tr>
        `;
      })
      .join("");

    container.innerHTML = `
      ${noticeHtml}
      <table class="leaderboard-table">
        <thead>
          <tr>
            <th>#</th>
            <th>Squadra</th>
            <th>Punti</th>
            <th>Tempo</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    `;
    sessionStorage.removeItem("its-quest-last-result");
  }

  async function load() {
    try {
      const res = await fetch("/api/leaderboard?limit=100");
      const data = await res.json();
      if (!data.ok || !Array.isArray(data.entries)) throw new Error("risposta non valida");
      render(data.entries);
    } catch (err) {
      render(
        window.LocalScores.today(),
        "Il server del gioco non risponde: questa è la classifica salvata solo su questo dispositivo. " +
          "Per la classifica condivisa avviate il gioco con AVVIA-GIOCO.bat e aprite http://localhost:3000."
      );
    }
  }

  load();
})();
