# ITS Olivetti Quest

Gioco web per l'open day di ITS Academy Adriano Olivetti: le squadre giocano 5 livelli
(ognuno raggruppa corsi affini), con minigiochi sulle competenze trasversali; dopo ogni
livello vengono mostrati descrizione e sede dei corsi. Classifica del giorno condivisa.
Tutti i testi del gioco sono in italiano.

## Avvio
- Windows: doppio clic su `AVVIA-GIOCO.bat` (installa, avvia, apre http://localhost:3000).
- Oppure: `npm install`, poi `npm start`.
- Modalità admin: scrivere la parola segreta come nome squadra (predefinita `daddala`,
  sovrascrivibile con la variabile d'ambiente `ADMIN_PASSWORD`). Resta solo sul server:
  non metterla nel codice di `public/`.

## Struttura
- `server.js` – Express: file statici + API (`/api/check-name`, `/api/score`,
  `/api/leaderboard`, `/api/settings`, `/api/admin/login`, `/api/admin/settings`).
  Valida i punteggi (max 150 punti per elemento, vedi `scoredItems`).
- `store.js` / `settings.js` – classifica e tempo base salvati in `data/*.json`.
- `public/js/courses.js` – livelli, minigiochi (quiz, memory, acchiappa, impiccato) e corsi
  con sedi. Fonte: itsolivetti.it/corso. Usato anche dal server per i limiti di punteggio.
- `public/js/game.js` – motore: HUD (vite, punti, livello), mappa, stelle, vite, salto
  livello, schermata finale. I timer dei minigiochi passano dallo "scope" del livello
  (`ctx.later`, `ctx.every`, `ctx.listen`) così il pulsante Salta li ferma tutti.
- `public/js/minigames.js` – memory, acchiappa le parole, impiccato.
- `public/js/profanity.js` – filtro nomi volgari, usato sia dal browser sia dal server.
- `public/js/local-scores.js` – classifica di riserva nel browser se il server non risponde.
- `public/style.css` – tema scuro; colori in `:root`. Layout per telefono, computer
  (≥900px) e proiettore (≥1400px).

## Note per le modifiche
- Le domande devono restare comprensibili a chiunque (niente conoscenze tecniche).
- Dopo modifiche al server riavviarlo; le pagine si aggiornano ricaricando.
- Per provare l'invio di punteggi senza sporcare la classifica vera, usare una copia
  del progetto su un'altra porta (`PORT=3077 node server.js`).
